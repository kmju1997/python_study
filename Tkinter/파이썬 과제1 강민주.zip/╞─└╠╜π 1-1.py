a = input("첫번째 숫자를 입력하세요 ")
b = input("두번째 숫자를 입력하세요 ")
a = int(a)
b = int(b)
if a%2==1:
    print("첫번째 수는 홀수입니다.")
else :
    print("첫번째 수는 짝수입니다.")

if b%2==1:
    print("두번째 수는 홀수입니다.")
else :
    print("두번째 수는 짝수입니다.")

