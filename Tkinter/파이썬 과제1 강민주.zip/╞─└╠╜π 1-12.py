a=input("알파벳을 입력하세요 ")
if a=='a' or a=='e' or a=='u' or a=='i' or a=='o':
    print("이 알파벳은 모음입니다.")
else:
    print("이 알파벳은 자음입니다.")
