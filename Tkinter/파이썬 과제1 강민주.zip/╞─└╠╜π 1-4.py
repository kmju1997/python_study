sum_list=[1,2,-20]
num=0
for i in sum_list:
    num +=i
print(num)    
