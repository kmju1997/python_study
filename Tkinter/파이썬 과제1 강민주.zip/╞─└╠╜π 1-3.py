name=input("이름을 입력하세요. ")
age=input("나이를 입력하세요. ")
age = int(age)
rest= 100-age
print("%d년 후에 100살이 됩니다!" %rest)
