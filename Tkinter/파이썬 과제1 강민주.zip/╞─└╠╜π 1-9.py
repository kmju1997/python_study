line=1
length=1
while line<5 :
    while line==length :
        print('*'*length)
        line+=1
    length+=1
while line<8:    
    while line+length==8:
        print('*'*length)
        line+=1
    length-=1
    


        
    
    
